﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToeRaspberryPi
{
    public partial class Form1 : Form
    {
        private int counter = 0;
        private int counterX = 0;
        private int counterO = 0;

        public Form1()
        {
            InitializeComponent();
            button1.Click += new EventHandler(button_Click);
            button2.Click += new EventHandler(button_Click);
            button3.Click += new EventHandler(button_Click);
            button4.Click += new EventHandler(button_Click);
            button5.Click += new EventHandler(button_Click);
            button6.Click += new EventHandler(button_Click);
            button7.Click += new EventHandler(button_Click);
            button8.Click += new EventHandler(button_Click);
            button9.Click += new EventHandler(button_Click);
            buttonReset.Click += new EventHandler(buttonReset_Click);
            buttonReset2.Click += new EventHandler(buttonReset2_Click);
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            button.Text = (counter % 2 == 0) ? "X" : "O";
            button.Enabled = false;
            counter++;
            labelPlayer.Text = (counter % 2 == 0) ? "x" : "o";
            CheckForWinner();
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            counter = 0;
            labelWinner.Text = "_";
            labelPlayer.Text = "x";
            EnableButtons();
            ResetButtons();
        }

        private void buttonReset2_Click(object sender, EventArgs e)
        {
            counterX = 0;
            counterO = 0;
            labelCounterX.Text = counterX.ToString();
            labelCounterO.Text = counterO.ToString();
        }

        private void CheckForWinner()
        {
            if (CheckLine(button1, button2, button3) ||
                CheckLine(button4, button5, button6) ||
                CheckLine(button7, button8, button9) ||
                CheckLine(button1, button4, button7) ||
                CheckLine(button2, button5, button8) ||
                CheckLine(button3, button6, button9) ||
                CheckLine(button1, button5, button9) ||
                CheckLine(button3, button5, button7))
            {
                string winner = (counter % 2 == 0) ? "O" : "X";
                labelWinner.Text = winner;
                DisableButtons();
                buttonReset.Enabled = true;

                if (winner == "X")
                    counterX++;
                else if (winner == "O")
                    counterO++;

                labelCounterX.Text = counterX.ToString();
                labelCounterO.Text = counterO.ToString();
            }
            else if (counter == 9)
            {
                labelWinner.Text = "Draw";
                buttonReset.Enabled = true;
            }
        }

        private bool CheckLine(Button button1, Button button2, Button button3)
        {
            return button1.Text != "" && button1.Text == button2.Text && button2.Text == button3.Text;
        }

        private void DisableButtons()
        {
            foreach (Control control in Controls)
            {
                if (control is Button button && button.Name != "buttonReset" && button.Name != "buttonReset2")
                {
                    button.Enabled = false;
                }
            }
        }

        private void EnableButtons()
        {
            foreach (Control control in Controls)
            {
                if (control is Button button && button.Name != "buttonReset" && button.Name != "buttonReset2")
                {
                    button.Enabled = true;
                }
            }
        }

        private void ResetButtons()
        {
            foreach (Control control in Controls)
            {
                if (control is Button button && button.Name != "buttonReset" && button.Name != "buttonReset2")
                {
                    button.Text = "";
                    button.Enabled = true;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Handle button1 click event
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Handle button2 click event
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Handle button3 click event
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Handle button4 click event
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Handle button5 click event
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Handle button6 click event
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // Handle button7 click event
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // Handle button8 click event
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // Handle button9 click event
        }
    }
}