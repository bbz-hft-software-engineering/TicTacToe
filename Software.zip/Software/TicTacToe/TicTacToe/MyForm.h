#pragma once

namespace TicTacToe {
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	//Rundencounter
	int counter = 0;

	//Spielstandcounter
	int counterX = 0;
	int counterO = 0;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			
			//Alle Buttons in einer Funktion zusammengefasst f�r diverse Abfragen
			button1->Click += gcnew System::EventHandler(this, &MyForm::button_Click);
			button2->Click += gcnew System::EventHandler(this, &MyForm::button_Click);
			button3->Click += gcnew System::EventHandler(this, &MyForm::button_Click);
			button4->Click += gcnew System::EventHandler(this, &MyForm::button_Click);
			button5->Click += gcnew System::EventHandler(this, &MyForm::button_Click);
			button6->Click += gcnew System::EventHandler(this, &MyForm::button_Click);
			button7->Click += gcnew System::EventHandler(this, &MyForm::button_Click);
			button8->Click += gcnew System::EventHandler(this, &MyForm::button_Click);
			button9->Click += gcnew System::EventHandler(this, &MyForm::button_Click);	
			buttonReset->Click += gcnew System::EventHandler(this, &MyForm::buttonReset_Click);
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ labelPlayer;
	private: System::Windows::Forms::Label^ labelWinner;
	private: System::Windows::Forms::Label^ labelPlayerText;
	private: System::Windows::Forms::Label^ labelWinnerText;
	private: System::Windows::Forms::Button^ buttonReset;
	private: System::Windows::Forms::Label^ labelX;
	private: System::Windows::Forms::Label^ labelO;
	private: System::Windows::Forms::Label^ labelCounterX;
	private: System::Windows::Forms::Label^ labelCounterO;
	private: System::Windows::Forms::Button^ buttonReset2;






	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->labelPlayer = (gcnew System::Windows::Forms::Label());
			this->labelWinner = (gcnew System::Windows::Forms::Label());
			this->labelPlayerText = (gcnew System::Windows::Forms::Label());
			this->labelWinnerText = (gcnew System::Windows::Forms::Label());
			this->buttonReset = (gcnew System::Windows::Forms::Button());
			this->labelX = (gcnew System::Windows::Forms::Label());
			this->labelO = (gcnew System::Windows::Forms::Label());
			this->labelCounterX = (gcnew System::Windows::Forms::Label());
			this->labelCounterO = (gcnew System::Windows::Forms::Label());
			this->buttonReset2 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(114, 99);
			this->button1->Margin = System::Windows::Forms::Padding(2);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(65, 53);
			this->button1->TabIndex = 0;
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(183, 99);
			this->button2->Margin = System::Windows::Forms::Padding(2);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(65, 53);
			this->button2->TabIndex = 1;
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(251, 99);
			this->button3->Margin = System::Windows::Forms::Padding(2);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(65, 53);
			this->button3->TabIndex = 2;
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(114, 156);
			this->button4->Margin = System::Windows::Forms::Padding(2);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(65, 53);
			this->button4->TabIndex = 3;
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(183, 156);
			this->button5->Margin = System::Windows::Forms::Padding(2);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(65, 53);
			this->button5->TabIndex = 4;
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(251, 156);
			this->button6->Margin = System::Windows::Forms::Padding(2);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(65, 53);
			this->button6->TabIndex = 5;
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm::button6_Click);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(114, 213);
			this->button7->Margin = System::Windows::Forms::Padding(2);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(65, 53);
			this->button7->TabIndex = 6;
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm::button7_Click);
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(183, 213);
			this->button8->Margin = System::Windows::Forms::Padding(2);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(65, 53);
			this->button8->TabIndex = 7;
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm::button8_Click);
			// 
			// button9
			// 
			this->button9->Location = System::Drawing::Point(251, 213);
			this->button9->Margin = System::Windows::Forms::Padding(2);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(65, 53);
			this->button9->TabIndex = 8;
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &MyForm::button9_Click);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(0, 0);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 20);
			this->textBox2->TabIndex = 0;
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(0, 0);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 20);
			this->textBox1->TabIndex = 0;
			// 
			// labelPlayer
			// 
			this->labelPlayer->AutoSize = true;
			this->labelPlayer->Font = (gcnew System::Drawing::Font(L"Arial", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelPlayer->Location = System::Drawing::Point(286, 65);
			this->labelPlayer->Name = L"labelPlayer";
			this->labelPlayer->Size = System::Drawing::Size(30, 32);
			this->labelPlayer->TabIndex = 11;
			this->labelPlayer->Text = L"x";
			// 
			// labelWinner
			// 
			this->labelWinner->AutoSize = true;
			this->labelWinner->Font = (gcnew System::Drawing::Font(L"Arial", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelWinner->Location = System::Drawing::Point(286, 268);
			this->labelWinner->Name = L"labelWinner";
			this->labelWinner->Size = System::Drawing::Size(30, 32);
			this->labelWinner->TabIndex = 12;
			this->labelWinner->Text = L"_";
			// 
			// labelPlayerText
			// 
			this->labelPlayerText->AutoSize = true;
			this->labelPlayerText->Font = (gcnew System::Drawing::Font(L"Arial", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelPlayerText->Location = System::Drawing::Point(108, 65);
			this->labelPlayerText->Name = L"labelPlayerText";
			this->labelPlayerText->Size = System::Drawing::Size(107, 32);
			this->labelPlayerText->TabIndex = 15;
			this->labelPlayerText->Text = L"Player:";
			// 
			// labelWinnerText
			// 
			this->labelWinnerText->AutoSize = true;
			this->labelWinnerText->Font = (gcnew System::Drawing::Font(L"Arial", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelWinnerText->Location = System::Drawing::Point(108, 268);
			this->labelWinnerText->Name = L"labelWinnerText";
			this->labelWinnerText->Size = System::Drawing::Size(118, 32);
			this->labelWinnerText->TabIndex = 16;
			this->labelWinnerText->Text = L"Winner:";
			// 
			// buttonReset
			// 
			this->buttonReset->Font = (gcnew System::Drawing::Font(L"Arial", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonReset->Location = System::Drawing::Point(12, 12);
			this->buttonReset->Name = L"buttonReset";
			this->buttonReset->Size = System::Drawing::Size(78, 32);
			this->buttonReset->TabIndex = 17;
			this->buttonReset->Text = L"Reset";
			this->buttonReset->UseVisualStyleBackColor = true;
			this->buttonReset->Click += gcnew System::EventHandler(this, &MyForm::buttonReset_Click);
			// 
			// labelX
			// 
			this->labelX->AutoSize = true;
			this->labelX->Font = (gcnew System::Drawing::Font(L"Arial", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelX->Location = System::Drawing::Point(108, 300);
			this->labelX->Name = L"labelX";
			this->labelX->Size = System::Drawing::Size(43, 32);
			this->labelX->TabIndex = 18;
			this->labelX->Text = L"X:";
			// 
			// labelO
			// 
			this->labelO->AutoSize = true;
			this->labelO->Font = (gcnew System::Drawing::Font(L"Arial", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelO->Location = System::Drawing::Point(105, 332);
			this->labelO->Name = L"labelO";
			this->labelO->Size = System::Drawing::Size(46, 32);
			this->labelO->TabIndex = 19;
			this->labelO->Text = L"O:";
			// 
			// labelCounterX
			// 
			this->labelCounterX->AutoSize = true;
			this->labelCounterX->Font = (gcnew System::Drawing::Font(L"Arial", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelCounterX->Location = System::Drawing::Point(286, 300);
			this->labelCounterX->Name = L"labelCounterX";
			this->labelCounterX->Size = System::Drawing::Size(30, 32);
			this->labelCounterX->TabIndex = 20;
			this->labelCounterX->Text = L"0";
			// 
			// labelCounterO
			// 
			this->labelCounterO->AutoSize = true;
			this->labelCounterO->Font = (gcnew System::Drawing::Font(L"Arial", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelCounterO->Location = System::Drawing::Point(286, 332);
			this->labelCounterO->Name = L"labelCounterO";
			this->labelCounterO->Size = System::Drawing::Size(30, 32);
			this->labelCounterO->TabIndex = 21;
			this->labelCounterO->Text = L"0";
			// 
			// buttonReset2
			// 
			this->buttonReset2->Font = (gcnew System::Drawing::Font(L"Arial", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonReset2->Location = System::Drawing::Point(322, 314);
			this->buttonReset2->Name = L"buttonReset2";
			this->buttonReset2->Size = System::Drawing::Size(52, 27);
			this->buttonReset2->TabIndex = 22;
			this->buttonReset2->Text = L"Reset";
			this->buttonReset2->UseVisualStyleBackColor = true;
			this->buttonReset2->Click += gcnew System::EventHandler(this, &MyForm::buttonReset2_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(429, 399);
			this->Controls->Add(this->buttonReset2);
			this->Controls->Add(this->labelCounterO);
			this->Controls->Add(this->labelCounterX);
			this->Controls->Add(this->labelO);
			this->Controls->Add(this->labelX);
			this->Controls->Add(this->buttonReset);
			this->Controls->Add(this->labelWinnerText);
			this->Controls->Add(this->labelPlayerText);
			this->Controls->Add(this->labelWinner);
			this->Controls->Add(this->labelPlayer);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Name = L"MyForm";
			this->Text = L"Tic Tac Toe";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	
	//Wenn ein beliebiger Button gedr�ckt wird, wird anhand des Rundencounters ermittelt, welcher Spieler dran ist. Dies wird im labelPlayer angezeigt
	private: System::Void button_Click(System::Object^ sender, System::EventArgs^ e) {

		if (counter % 2 == 1) {
			labelPlayer->Text = "o";
		}
		else {
			labelPlayer->Text = "x";
		}
		CheckForWinner();

	}

	//Wenn dieser Button gedr�ckt wird, wird anhand des Rundencounters das SPielersymbol eingef�gt. Der Rundencounter z�hlt um eins hoch und der Button wird deaktiviert.
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

		if (counter % 2 == 1) {
			button1->Text = "o";
		}
		else {
			button1->Text = "x";
		}

		button1->Enabled = false;
		counter++;
	}

	//Wenn dieser Button gedr�ckt wird, wird anhand des Rundencounters das SPielersymbol eingef�gt. Der Rundencounter z�hlt um eins hoch und der Button wird deaktiviert.
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
		if (counter % 2 == 1) {
			button2->Text = "o";
		}
		else {
			button2->Text = "x";
		}

		button2->Enabled = false;
		counter++;
	}

	//Wenn dieser Button gedr�ckt wird, wird anhand des Rundencounters das SPielersymbol eingef�gt. Der Rundencounter z�hlt um eins hoch und der Button wird deaktiviert.
	private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {

		if (counter % 2 == 1) {
			button3->Text = "o";
		}
		else {
			button3->Text = "x";
		}

		button3->Enabled = false;
		counter++;
	}

	//Wenn dieser Button gedr�ckt wird, wird anhand des Rundencounters das SPielersymbol eingef�gt. Der Rundencounter z�hlt um eins hoch und der Button wird deaktiviert.
	private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {

		if (counter % 2 == 1) {
			button4->Text = "o";
		}
		else {
			button4->Text = "x";
		}

		button4->Enabled = false;
		counter++;

	}

	//Wenn dieser Button gedr�ckt wird, wird anhand des Rundencounters das SPielersymbol eingef�gt. Der Rundencounter z�hlt um eins hoch und der Button wird deaktiviert.
	private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {

		if (counter % 2 == 1) {
			button5->Text = "o";
		}
		else {
			button5->Text = "x";
		}

		button5->Enabled = false;
		counter++;
	}

	//Wenn dieser Button gedr�ckt wird, wird anhand des Rundencounters das SPielersymbol eingef�gt. Der Rundencounter z�hlt um eins hoch und der Button wird deaktiviert.
	private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {

		if (counter % 2 == 1) {
			button6->Text = "o";
		}
		else {
			button6->Text = "x";
		}

		button6->Enabled = false;
		counter++;
	}

	//Wenn dieser Button gedr�ckt wird, wird anhand des Rundencounters das SPielersymbol eingef�gt. Der Rundencounter z�hlt um eins hoch und der Button wird deaktiviert.
	private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {

		if (counter % 2 == 1) {
			button7->Text = "o";
		}
		else {
			button7->Text = "x";
		}

		button7->Enabled = false;
		counter++;
	}

	//Wenn dieser Button gedr�ckt wird, wird anhand des Rundencounters das SPielersymbol eingef�gt. Der Rundencounter z�hlt um eins hoch und der Button wird deaktiviert.
	private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {

		if (counter % 2 == 1) {
			button8->Text = "o";
		}
		else {
			button8->Text = "x";
		}

		button8->Enabled = false;
		counter++;
	}

	//Wenn dieser Button gedr�ckt wird, wird anhand des Rundencounters das SPielersymbol eingef�gt. Der Rundencounter z�hlt um eins hoch und der Button wird deaktiviert.
	private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {

		if (counter % 2 == 1) {
			button9->Text = "o";
		}
		else {
			button9->Text = "x";
		}

		button9->Enabled = false;
		counter++;
	}

	//Funktion f�r den Reset Button. Es werden alle Spielersymbole gel�scht, der Counter zur�ckgesetzt und alle Buttons wieder aktiviert
	private: System::Void buttonReset_Click(System::Object^ sender, System::EventArgs^ e) {

		//Reset all buttons
		button1->Text = "";
		button2->Text = "";
		button3->Text = "";
		button4->Text = "";
		button5->Text = "";
		button6->Text = "";
		button7->Text = "";
		button8->Text = "";
		button9->Text = "";

		button1->Enabled = true;
		button2->Enabled = true;
		button3->Enabled = true;
		button4->Enabled = true;
		button5->Enabled = true;
		button6->Enabled = true;
		button7->Enabled = true;
		button8->Enabled = true;
		button9->Enabled = true;

		//Reset the counter
		counter = 0;

		//Reset labels
		labelPlayer->Text = "X";
		labelWinner->Text = "";
	}

	//Funktion f�r den Resetbutton Spielstand.
	private: System::Void buttonReset2_Click(System::Object^ sender, System::EventArgs^ e) {

		//Reset and update all counters
		counterO = 0;
		counterX = 0;
		UpdateCounterO();
		UpdateCounterX();
	}

	//Funktion f�r die Gewinnerermittlung
	void CheckForWinner()
	{
		bool isWinner = false;

		//�berpr�fung Zeile. Wenn alle Buttons in einer Zeile das selbe Symbol haben, ist die Gewinnbedingung erf�llt.
		if ((button1->Text == button2->Text && button2->Text == button3->Text) && button1->Text != "")
			isWinner = true;
		else if ((button4->Text == button5->Text && button5->Text == button6->Text) && button4->Text != "")
			isWinner = true;
		else if ((button7->Text == button8->Text && button8->Text == button9->Text) && button7->Text != "")
			isWinner = true;

		//�berpr�fung Spalte. Wenn alle Buttons in einer Spalte das selbe Symbol haben, ist die Gewinnbedingung erf�llt.
		else if ((button1->Text == button4->Text && button4->Text == button7->Text) && button1->Text != "")
			isWinner = true;
		else if ((button2->Text == button5->Text && button5->Text == button8->Text) && button2->Text != "")
			isWinner = true;
		else if ((button3->Text == button6->Text && button6->Text == button9->Text) && button3->Text != "")
			isWinner = true;

		//�berpr�fung Diagonale. Wenn alle Buttons in einer Diagonale das selbe Symbol haben, ist die Gewinnbedingung erf�llt.
		else if ((button1->Text == button5->Text && button5->Text == button9->Text) && button1->Text != "")
			isWinner = true;
		else if ((button3->Text == button5->Text && button5->Text == button7->Text) && button3->Text != "")
			isWinner = true;

		//Anhand des Counters wird ermittelt, welcher Spieler gewonnen hat.
		if (isWinner)
		{
			String^ winner = "";
			if (counter % 2 == 0) {	

				winner = "O";
				counterO++;
				UpdateCounterO();
				
			}
			

			else {
				winner = "X";
				counterX++;
				UpdateCounterX();
				
			}
				

			labelWinner->Text = winner;
			DisableButtons();
		}

		//Erreicht der Rundencounter 9 und es steht kein Gewinner fest, gibt es ein Unentschieden
		else if (counter == 9)
		{
			labelWinner->Text = "Tie";
		}
	}

	//Hier werden alle Buttons deaktiviert
	void DisableButtons()
	{
		button1->Enabled = false;
		button2->Enabled = false;
		button3->Enabled = false;
		button4->Enabled = false;
		button5->Enabled = false;
		button6->Enabled = false;
		button7->Enabled = false;
		button8->Enabled = false;
		button9->Enabled = false;
	}

	void UpdateCounterX()
	{
		labelCounterX->Text = counterX.ToString();
	}

	void UpdateCounterO()
	{
		labelCounterO->Text = counterO.ToString();
	}

}


; }
	

